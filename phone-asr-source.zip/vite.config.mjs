import { defineConfig } from 'vite';
// Relative asset URLs work at /<repo>/ on GitHub Pages and at a root origin.
// GitHub Pages does not let us add COOP/COEP. WASM stays single-threaded.
export default defineConfig({ base: './', build: { target: 'es2022', assetsInlineLimit: 0 }});

export const MODEL_ID = 'onnx-community/whisper-tiny'; // multilingual; never .en
export const SAMPLE_RATE = 16000;
export const MAX_SECONDS = 30;
export const MAX_SOURCE_BYTES = 16 * 1024 * 1024;
export const LOCALES = Object.freeze(['pt-PT','pt-BR']);
export function localeGuard(locale) {
  if (!LOCALES.includes(locale)) throw new Error('Locale must be pt-PT or pt-BR');
  return locale;
}
export function deviceKind(preference, available) {
  if (preference === 'cpu') return 'wasm';
  if (preference === 'gpu' && !available) throw new Error('WebGPU unavailable: choose CPU.');
  if (preference === 'gpu' || (preference === 'auto' && available)) return 'webgpu';
  if (preference === 'auto') return 'wasm';
  throw new Error('Unsupported device preference');
}
export function inferenceOptions(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0 || seconds > MAX_SECONDS) throw new Error('Invalid audio duration');
  return { language: 'portuguese', task: 'transcribe', return_timestamps: false,
    max_new_tokens: Math.max(16, Math.min(224, Math.ceil(seconds * 7)+8)) };
}
export function receipt({locale, backend, ms, text, onlineHint, audioHash, source, speakerReviewed=false}) {
  localeGuard(locale);
  if (!['webgpu','wasm'].includes(backend)) throw new Error('No successful backend');
  if (!Number.isFinite(ms) || ms < 0 || typeof text !== 'string') throw new Error('Invalid inference');
  return {schema: 'phone-only-asr-observation-v1', created_utc: new Date().toISOString(),
    target_locale: locale, language: 'portuguese', accent_detected: false,
    source: String(source || 'unspecified'), source_speaker_reviewed: Boolean(speakerReviewed),
    engine: 'transformers.js', model: MODEL_ID, effective_device: backend,
    elapsed_inference_ms: Math.round(ms), transcript: text,
    audio_sha256: audioHash || 'not-available',
    connection_hint_from_browser: onlineHint ? 'online' : 'offline_hint_only',
    proof_of_airplane_mode: 'NOT_ATTESTED', proof_of_physical_iphone: 'NOT_ATTESTED',
    model_integrity_review: 'NOT_ATTESTED', corpus_reference_transcript: 'NOT_PROVIDED',
    study_minutes: 0, learning_progress_updated: false,
    warning: 'Requires independent physical iPhone and offline observations; no learning hours earned.'};
}
export function validateBundlePolicy(paths) {
  // Optional CI static policy check; never package the user's private master learning state.
  return paths.every(p => !/(PROGRAM_STATE|LEARNING\/|HISTORY\/|\.wav$|\.m4a$|ggml-base\.bin$)/i.test(p));
}

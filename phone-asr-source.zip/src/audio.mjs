import {SAMPLE_RATE, MAX_SECONDS, MAX_SOURCE_BYTES} from './policy.mjs';
export function downmix(channels) {
  if (!Array.isArray(channels) || channels.length < 1 || channels.length > 8) throw new Error('Invalid channels');
  const length=channels[0].length;
  if(!length) throw new Error('Empty audio');
  const out=new Float32Array(length);
  for(const c of channels) {
    if(!(c instanceof Float32Array) || c.length!==length) throw new Error('Mismatched channels');
    for(let i=0;i<length;i++) out[i]+=c[i]/channels.length;
  }
  return out;
}
export function linearResample(samples, fromRate, toRate=SAMPLE_RATE) {
  if (!(samples instanceof Float32Array) || samples.length===0) throw new Error('Empty PCM');
  if(!Number.isFinite(fromRate)||fromRate<8000||fromRate>192000) throw new Error('Invalid input rate');
  if (samples.length/fromRate > MAX_SECONDS+0.05) throw new Error('Clip is too long');
  const targetLength=Math.round(samples.length*toRate/fromRate);
  if(targetLength===0) throw new Error('Insufficient samples');
  const result=new Float32Array(targetLength);
  for(let i=0;i<targetLength;i++) {
    const pos=i*fromRate/toRate, left=Math.min(samples.length-1,Math.floor(pos));
    const right=Math.min(samples.length-1,left+1), w=pos-left;
    const value=samples[left]*(1-w)+samples[right]*w;
    if(!Number.isFinite(value)) throw new Error('Non-finite audio');
    result[i]=Math.max(-1, Math.min(1,value));
  }
  return result;
}
// Prefer the browser's anti-aliased resampling pipeline when available.
// A deliberately explicit JS fallback is kept for environments without OfflineAudioContext;
// any fallback result is still labelled as a pilot, not a pronunciation-quality certificate.
export async function resampleForRecognition(samples, fromRate,
    offlineFactory=(channels,length,rate)=>new OfflineAudioContext(channels,length,rate)) {
  if(fromRate===SAMPLE_RATE)return samples;
  const length=Math.round(samples.length*SAMPLE_RATE/fromRate);
  if(length<1 || length>MAX_SECONDS*SAMPLE_RATE+1)throw new Error('Unsupported resampled duration');
  if(typeof OfflineAudioContext==='undefined')return linearResample(samples,fromRate);
  try {
    const offline=offlineFactory(1,length,SAMPLE_RATE);
    const sourceBuffer=offline.createBuffer(1,samples.length,fromRate);
    sourceBuffer.copyToChannel(samples,0);
    const source=offline.createBufferSource();source.buffer=sourceBuffer;
    source.connect(offline.destination);source.start(0);
    const output=await offline.startRendering();
    const pcm=output.getChannelData(0);
    if(pcm.length!==length)throw new Error('Unexpected resampler output length');
    return new Float32Array(pcm);
  }catch{
    // A device may expose OfflineAudioContext but fail to initialize the requested rate.
    return linearResample(samples,fromRate);
  }
}
export async function decodeBlobTo16k(blob, makeContext=()=>new AudioContext()) {
  if(!blob || !Number.isFinite(blob.size) || blob.size<=0 || blob.size>MAX_SOURCE_BYTES) throw new Error('Invalid or oversized audio file');
  const context=makeContext();
  try {
    const raw=await blob.arrayBuffer();
    const buffer=await context.decodeAudioData(raw);
    if(buffer.duration > MAX_SECONDS+0.01) throw new Error('Maximum clip duration is 30 seconds');
    if(buffer.duration<0.15) throw new Error('Audio too short');
    const channels=[];
    for(let i=0;i<buffer.numberOfChannels;i++) channels.push(buffer.getChannelData(i));
    const pcm=await resampleForRecognition(downmix(channels),buffer.sampleRate);
    if(pcm.length>MAX_SECONDS*SAMPLE_RATE+1) throw new Error('Audio exceeds PCM cap');
    // Reject silence: Whisper sometimes hallucinates on silence.
    let sum=0;
    for(const v of pcm)sum+=v*v;
    if(Math.sqrt(sum/pcm.length)<0.0005) throw new Error('Almost silent audio');
    return pcm;
  } finally { await context.close?.(); }
}
export async function digestSha256(blob) {
  if(!globalThis.crypto?.subtle) return null;
  const bytes=await blob.arrayBuffer();
  const hash=await crypto.subtle.digest('SHA-256',bytes);
  return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
}

import {LocalWhisperEngine,findUsableGPU} from './engine.mjs';
import {decodeBlobTo16k,digestSha256} from './audio.mjs';
import {localeGuard,MAX_SOURCE_BYTES,MAX_SECONDS,receipt} from './policy.mjs';

const el=id=>document.getElementById(id);
let engine=null, backend=null, selectedBlob=null, selectedSource='',resultReceipt=null;
let mediaRecorder=null, mediaStream=null, recordingTimer=null;
const status=message=>el('status').textContent=message;
let busy=false;
function refresh() {
  el('load').disabled=busy||!!backend;
  el('unload').disabled=busy||!backend;
  el('run').disabled=busy||!backend||!selectedBlob;
  el('export').disabled=busy||!resultReceipt;
  el('record').disabled=busy||!!mediaRecorder;
  el('stop').disabled=!mediaRecorder;
  el('file').disabled=busy||!!mediaRecorder;
  el('backend').disabled=busy||!!backend;
}
async function work(fn) {
  if(busy)return;
  busy=true;refresh();
  try {await fn();}catch(e){status(`Error: ${e?.message||String(e)}. No study progress credited.`);}
  finally{busy=false;refresh();}
}
function dropResult() {resultReceipt=null;el('transcript').value='';}
function choose(blob,source,label=source) {
  if(blob.size<=0||blob.size>MAX_SOURCE_BYTES) throw new Error('Recording is empty or over 16 MiB');
  selectedBlob=blob;selectedSource=source;dropResult();
  el('selection').textContent=`Selected ${label} (${(blob.size/1024).toFixed(1)} KiB)`;
  refresh();
}
async function detect() {
  const gpu=await findUsableGPU();
  el('capability').textContent=`Secure origin: ${isSecureContext?'yes':'NO'} | WebGPU adapter: ${gpu?'available':'not available'} | App shell service worker: ${'serviceWorker' in navigator?'supported':'unsupported'} | Online hint: ${navigator.onLine?'online':'offline'} (not attestation)`;
  return gpu;
}
async function storageStatus(){
  try{
    const estimate=await navigator.storage?.estimate?.();
    const persisted=await navigator.storage?.persisted?.();
    if(!estimate) {el('storage').textContent='Browser storage estimate unavailable; model caching must be tested manually.';return;}
    const m=x=>Math.round(x/1024/1024);
    el('storage').textContent=`Approx. site storage: ${m(estimate.usage||0)} MiB used / ${m(estimate.quota||0)} MiB quota. Persistence: ${persisted?'granted':'not established'}. Cache can still be evicted; airplane-mode verification is essential.`;
  }catch{el('storage').textContent='Browser storage status unavailable; this does not block online testing.';}
}
storageStatus();
let gpuPromise=detect();
if('serviceWorker' in navigator && isSecureContext) {
  navigator.serviceWorker.register('./sw.js').catch(e=>status(`Service worker unavailable: ${e.message}. Online use may still work.`));
}
el('load').addEventListener('click',()=>work(async()=>{
  status('Loading Transformers.js library and local multilingual model. The FIRST download requires a network.');
  const gpu=await gpuPromise;
  const preference=el('backend').value;
  const {pipeline,env}=await import('@huggingface/transformers');
  // The ORT runtime is copied to our own origin at build time, not fetched from a CDN.
  env.backends.onnx.wasm.wasmPaths=new URL('./ort-wasm/', document.baseURI).href;
  engine=new LocalWhisperEngine({pipelineFactory:pipeline,envObject:env});
  backend=await engine.prepare({preference,hasGPU:gpu,onProgress:p=>{
    if(p?.status==='fallback')status('WebGPU failed; falling back to CPU/WASM. Additional model files may download.');
    else if (p?.status) status(`Preparing model: ${p.status}${typeof p.progress==='number'?' '+Math.round(p.progress)+'%':''}`);
  }});
  await storageStatus();
  status(`Whisper multilingual model initialized using ${backend}. Not yet evidence of successful transcription or offline use.`);
}));
el('unload').addEventListener('click',()=>work(async()=>{
  if(engine)await engine.unload();engine=null;backend=null;dropResult();
  status('Model released from working memory. Cached model files are not deleted. Choose CPU or WebGPU, then load again.');
}));
el('file').addEventListener('change',event=>{
  try {const file=event.target.files?.[0];if(file)choose(file,'local_file',file.name);}
  catch(e){selectedBlob=null;selectedSource='';dropResult();el('selection').textContent='No valid audio selected';status(e.message);refresh();}
});
el('locale').addEventListener('change',()=>{dropResult();status('Evaluation target changed. Previous result was cleared; retranscribe the same audio to create a correctly labelled observation.');refresh();});
el('run').addEventListener('click',()=>work(async()=>{
  const blob=selectedBlob,source=selectedSource;
  if(!blob||!engine) throw new Error('Select a clip and prepare the model first');
  status('Decoding audio entirely in your browser...');
  const [pcm,sha]=await Promise.all([decodeBlobTo16k(blob),digestSha256(blob)]);
  status(`Running multilingual Whisper on ${backend} (${(pcm.length/16000).toFixed(1)}s audio)...`);
  const output=await engine.transcribe(pcm);
  const text=output.text;
  el('transcript').value=text;
  resultReceipt=receipt({locale:localeGuard(el('locale').value),backend:output.backend,ms:output.ms,text,
    onlineHint:navigator.onLine,audioHash:sha,source});
  status(`Transcription completed in ${(output.ms/1000).toFixed(2)}s. Text is unverified. Audio was NOT sent to an application server. Offline and physical-device proof remain NOT_ATTESTED. Study minutes: 0.`);
}));
el('export').addEventListener('click',()=>{
  if(!resultReceipt) return;
  const blob=new Blob([JSON.stringify(resultReceipt,null,2)+'\n'],{type:'application/json'});
  const url=URL.createObjectURL(blob);const a=document.createElement('a');
  a.href=url;a.download='portuguese-local-asr-observation.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),2000);
});
el('discard').addEventListener('click',()=>{
  selectedBlob=null;selectedSource='';dropResult();el('file').value='';
  el('selection').textContent='No audio selected';status('Clip and transcript discarded from this page. Cached ML model is unaffected.');refresh();
});
el('record').addEventListener('click',async()=>{
  if(mediaRecorder||busy) return;
  try {
    if (!isSecureContext||!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined')
      throw new Error('Microphone capture requires Safari HTTPS plus permission');
    mediaStream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:false},video:false});
    const options=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));
    mediaRecorder=new MediaRecorder(mediaStream,options?{mimeType:options}:undefined);
    const parts=[];const recorder=mediaRecorder;
    recorder.ondataavailable=e=>{if(e.data.size>0)parts.push(e.data);};
    recorder.onerror=e=>status(`Recorder error: ${e.error?.message||'unknown'}`);
    recorder.onstop=()=>{
      clearTimeout(recordingTimer);
      mediaStream?.getTracks().forEach(t=>t.stop());mediaStream=null;mediaRecorder=null;
      try {choose(new Blob(parts,{type:recorder.mimeType||'audio/mp4'}),'microphone_recording');status('Local microphone clip ready. Click Transcribe locally.');}
      catch(e){status(`Recorder error: ${e.message}`);}refresh();
    };
    recorder.start(250);
    recordingTimer=setTimeout(()=>{if(recorder.state==='recording')recorder.stop();},20000);
    status('Recording locally for up to 20 seconds. Tap Stop when ready.');refresh();
  } catch(e) {
    mediaStream?.getTracks().forEach(t=>t.stop());mediaStream=null;mediaRecorder=null;
    status(`Cannot record: ${e.message}`);refresh();
  }
});
el('stop').addEventListener('click',()=>{if(mediaRecorder?.state==='recording')mediaRecorder.stop();});
window.addEventListener('beforeunload',()=>{
  if(mediaRecorder?.state==='recording')mediaRecorder.stop();
  mediaStream?.getTracks().forEach(t=>t.stop());
});
refresh();

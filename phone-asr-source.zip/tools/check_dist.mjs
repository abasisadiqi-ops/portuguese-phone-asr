import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import vm from 'node:vm';
import {inventory} from './finalize_sw.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist');
export function checkSite(root){
 const paths=inventory(root), sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
 if(!paths.includes('index.html')||!paths.includes('manifest.webmanifest'))throw Error('Missing PWA entry');
 for(const must of ['icon-180.png','icon-192.png','icon-512.png'])if(!paths.includes(must))throw Error(`Missing ${must}`);
 if(!paths.some(p=>p.startsWith('ort-wasm/')&&p.endsWith('.wasm')))throw Error('Missing local WASM');
 if(!paths.some(p=>p.startsWith('ort-wasm/')&&p.endsWith('.mjs')))throw Error('Missing WASM glue');
 if(!paths.some(p=>p.startsWith('assets/')&&p.endsWith('.js')))throw Error('Missing compiled application JS');
 for(const item of paths){
  if(/(^|\/)(LEARNING|HISTORY|WORKING|PROGRAM_STATE|\.|node_modules)(\/|$)/i.test(item)||/\.(wav|m4a|mp3|ogg|webm|bin|gguf|jsonl)$/i.test(item))throw Error(`Refuse private/media/non-web artifact: ${item}`);
  if(!sw.includes(item))throw Error(`Not offline-precached: ${item}`);
 }
 new vm.Script(sw,{filename:'sw.js'});
 const size=paths.reduce((n,p)=>n+fs.statSync(path.join(root,p)).size,0);
 if(size>160*1024*1024)throw Error(`Unexpectedly large deploy: ${size} bytes`);
 const start=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'));
 if(start.start_url!=='./'||start.scope!=='./')throw Error('PWA scope must be relative');
 return {files:paths.length,static_bytes:size,files_pre_cached:true,private_state_excluded:true};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(checkSite(root)));

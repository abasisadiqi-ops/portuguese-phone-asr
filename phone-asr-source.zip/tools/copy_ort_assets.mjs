import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=path.join(ROOT,'node_modules','onnxruntime-web','dist');
const dest=path.join(ROOT,'public','ort-wasm');
if(!fs.existsSync(source)) {console.error('onnxruntime-web not installed: npm install first');process.exit(2);}
fs.rmSync(dest,{recursive:true,force:true});fs.mkdirSync(dest,{recursive:true});
const files=fs.readdirSync(source).filter(f=>/^ort-wasm[\w.-]*\.(wasm|mjs)$/.test(f));
if (!files.some(f=>f.endsWith('.wasm'))||!files.some(f=>f.endsWith('.mjs'))) throw new Error('Incomplete ONNX WASM runtime: refuse build');
for (const f of files)fs.copyFileSync(path.join(source,f),path.join(dest,f));
console.log(`Bundled ${files.length} ONNX runtime assets on same origin`);

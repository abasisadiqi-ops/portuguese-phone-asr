import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dist=path.join(ROOT,'dist');
export function inventory(root){
  function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>{
    const full=path.join(dir,entry.name),rel=path.relative(root,full).replaceAll(path.sep,'/');
    if(entry.isSymbolicLink())throw new Error('Unexpected symlink in site output');
    return entry.isDirectory()?walk(full):[rel];
  });}
  return walk(root).filter(f=>f!=='sw.js'&&!f.endsWith('.map')&&!f.startsWith('.'));
}
export function finalize(root){
  const sourcePath=path.join(root,'sw.js');
  const inventoryList=inventory(root);
  if(!inventoryList.includes('index.html') || !inventoryList.includes('manifest.webmanifest')) throw new Error('Missing web app shell');
  if(!inventoryList.some(f=>f.startsWith('assets/')&&f.endsWith('.js'))) throw new Error('No bundled JS');
  if(!inventoryList.some(f=>f.startsWith('ort-wasm/')&&f.endsWith('.wasm'))) throw new Error('No offline ONNX runtime binary');
  // All same-origin runtime chunks and WASM included; these are needed even if first load was WebGPU.
  const precache=['./',...inventoryList].sort();
  const digest=crypto.createHash('sha256').update(precache.map(f=>f+' '+crypto.createHash('sha256').update(fs.readFileSync(path.join(root,f==='./'?'index.html':f))).digest('hex')).join('\n')).digest('hex').slice(0,16);
  const original=fs.readFileSync(sourcePath,'utf8');
  if(!original.includes("const CACHE='portuguese-asr-app-shell-dev';")|| !original.includes("const PRECACHE=['./','index.html','manifest.webmanifest'];"))throw new Error('Unexpected SW source: refuse silent partial rewrite');
  const result=original.replace("const CACHE='portuguese-asr-app-shell-dev';",`const CACHE='portuguese-asr-app-shell-${digest}';`)
    .replace("const PRECACHE=['./','index.html','manifest.webmanifest'];",`const PRECACHE=${JSON.stringify(precache)};`);
  fs.writeFileSync(sourcePath,result);
  return {precache:precache.length,build:digest,bytes:precache.filter(x=>x!=='./').reduce((s,x)=>s+fs.statSync(path.join(root,x)).size,0)};
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  if(!fs.existsSync(path.join(dist,'sw.js'))) throw new Error('vite build must precede SW finalization');
  console.log(JSON.stringify(finalize(dist)));
}

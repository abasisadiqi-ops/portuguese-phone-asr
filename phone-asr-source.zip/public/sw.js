/* Source SW: finalize_sw.mjs supplies exact version and compiled asset list.
 * Scope never reaches the user's private master project or third-party model endpoints.
 */
const CACHE='portuguese-asr-app-shell-dev';
const PRECACHE=['./','index.html','manifest.webmanifest'];
const PREFIX='portuguese-asr-app-shell-';
const root=self.registration.scope;
const withinScope=url=>url.origin===self.location.origin && url.href.startsWith(root);
const isAppDocument=req=>req.mode==='navigate';
self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    // Atomic addAll: don't install a partial shell with missing runtime dependencies.
    await cache.addAll(PRECACHE.map(file=>new URL(file,root).href));
    // Do not force activation over a tab still using old hashed bundles.
    // The update will activate after old controlled tabs close.
  })());
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(name=>name.startsWith(PREFIX)&&name!==CACHE).map(name=>caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(!withinScope(url))return; // No model interception, no external fetch interception.
  if(isAppDocument(req)){
    event.respondWith((async()=>{
      const shell=new URL('index.html',root).href;
      // Stable offline startup; online-first updates of the HTML shell.
      try{
        const response=await fetch(req);
        if(response.ok){const cache=await caches.open(CACHE);await cache.put(shell,response.clone());}
        return response;
      }catch{return await caches.match(shell) || Response.error();}
    })());
  }else{
    event.respondWith((async()=>{
      const hit=await caches.match(req);
      if(hit)return hit;
      // Lazy same-origin assets cache on first use (not model files).
      const response=await fetch(req);
      if(response.ok && response.type==='basic'){
        const cache=await caches.open(CACHE);await cache.put(req,response.clone());
      }
      return response;
    })());
  }
});

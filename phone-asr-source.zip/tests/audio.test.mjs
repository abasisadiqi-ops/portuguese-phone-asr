import test from 'node:test';import assert from 'node:assert/strict';
import {downmix,linearResample,resampleForRecognition,decodeBlobTo16k,digestSha256} from '../src/audio.mjs';
test('downmix retains length and averages',()=>{assert.deepEqual([...downmix([new Float32Array([0,1]),new Float32Array([1,-1])])],[.5,0]);});
test('resampling 48k to 16k yields 16k samples',()=>{const a=new Float32Array(48000);a.fill(.125);const b=linearResample(a,48000);assert.equal(b.length,16000);assert.ok(Math.abs(b[100]-.125)<1e-7);});
test('resampler rejects long/invalid inputs',()=>{assert.throws(()=>linearResample(new Float32Array(16000*31),16000));assert.throws(()=>linearResample(new Float32Array([1]),1));assert.throws(()=>downmix([]));assert.throws(()=>downmix([new Float32Array([1]),new Float32Array(2)]));});
test('decoding fixture returns PCM and closes context',async()=>{let closed=false;const file=new Blob(['wav data']);const context={decodeAudioData:async()=>({duration:1,sampleRate:16000,numberOfChannels:1,getChannelData:()=>new Float32Array(16000).fill(.2)}),close:async()=>{closed=true;}};const pcm=await decodeBlobTo16k(file,()=>context);assert.equal(pcm.length,16000);assert.equal(closed,true);});
test('rejects near silence',async()=>{const ctx={decodeAudioData:async()=>({duration:1,sampleRate:16000,numberOfChannels:1,getChannelData:()=>new Float32Array(16000)}),close:async()=>{}};await assert.rejects(decodeBlobTo16k(new Blob(['test']),()=>ctx));});
test('closes audio context on decode failure',async()=>{let closed=false;const ctx={decodeAudioData:()=>{throw new Error('bad')},close:async()=>{closed=true}};await assert.rejects(decodeBlobTo16k(new Blob(['a']),()=>ctx));assert.equal(closed,true);});
test('hash returns 64-character SHA-256 when available',async()=>{const {webcrypto}=await import('node:crypto');const before=globalThis.crypto;Object.defineProperty(globalThis,'crypto',{configurable:true,value:webcrypto});try{const hex=await digestSha256(new Blob(['abc']));assert.equal(hex,'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');}finally{Object.defineProperty(globalThis,'crypto',{configurable:true,value:before});}});

test('native OfflineAudioContext resampling path is used when available',async()=>{
 const before=globalThis.OfflineAudioContext;globalThis.OfflineAudioContext=function(){};
 let rate=0;
 try{
  const pcm=await resampleForRecognition(new Float32Array(24000).fill(.1),24000,(channels,n,sr)=>{
   rate=sr;return {createBuffer:()=>({copyToChannel:()=>{}}),createBufferSource:()=>({connect:()=>{},start:()=>{}}),startRendering:async()=>({getChannelData:()=>new Float32Array(n).fill(.125)})};
  });
  assert.equal(rate,16000);assert.equal(pcm.length,16000);assert.equal(pcm[100],.125);
 }finally{globalThis.OfflineAudioContext=before;}
});

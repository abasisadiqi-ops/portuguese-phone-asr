import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import vm from 'node:vm';
const sw=fs.readFileSync(new URL('../public/sw.js',import.meta.url),'utf8');
test('service worker only caches same-origin GETs',()=>{assert.match(sw,/req\.method!=='GET'/);assert.match(sw,/url\.origin===self\.location\.origin/);assert.match(sw,/url\.href\.startsWith\(root\)/);});
test('model cache is not tampered with',()=>{assert.match(sw,/keys\.filter\(name=>name\.startsWith\(PREFIX\)/);assert.doesNotMatch(sw,/caches\.delete\('whisper-models'\)/);});
test('valid script can execute in SW-like VM sandbox',()=>{
 const handlers={};const self={registration:{scope:'https://example.com/repo/'},location:{origin:'https://example.com'},clients:{claim:async()=>{}},skipWaiting:()=>{},addEventListener:(key,handler)=>handlers[key]=handler};
 vm.runInNewContext(sw,{self,caches:{},URL,Response,fetch:()=>{} });
 assert.equal(typeof handlers.install,'function');assert.equal(typeof handlers.fetch,'function');
});

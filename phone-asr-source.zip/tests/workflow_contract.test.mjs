import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const yaml=fs.readFileSync(new URL('../tools/phone_asr_workflow.yml',import.meta.url),'utf8');
test('GitHub build runs only when dispatched manually',()=>{assert.match(yaml,/workflow_dispatch:/);assert.doesNotMatch(yaml,/^\s+push:/m);assert.doesNotMatch(yaml,/^\s+pull_request:/m);});
test('Pages deployment requires explicit true, is separate from build',()=>{assert.match(yaml,/default: false/);assert.match(yaml,/if: \$\{\{ inputs\.deploy_pages \}\}/);assert.match(yaml,/pages: write/);assert.match(yaml,/id-token: write/);});
test('publishes only isolated site artifact, never LEARNING dir',()=>{assert.match(yaml,/\/tmp\/pt-asr-pwa\/dist\//);assert.doesNotMatch(yaml,/path:\s+\.\//);assert.match(yaml,/phone-asr-source\.zip/);});

import test from 'node:test';import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,mkdirSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';import path from 'node:path';
import {finalize} from '../tools/finalize_sw.mjs';
const swSource=readFileSync(new URL('../public/sw.js',import.meta.url),'utf8');
function fixture(fn){const p=mkdtempSync(path.join(tmpdir(),'phone-pwa-'));try{
 mkdirSync(path.join(p,'assets'));mkdirSync(path.join(p,'ort-wasm'));
 for(const [name,bytes] of Object.entries({'sw.js':swSource,'index.html':'<html></html>','manifest.webmanifest':'{}','assets/index-ABCD.js':'console.log(1)','assets/worker-xyz.js':'console.log(2)','ort-wasm/ort-wasm.wasm':'binary','ort-wasm/ort-wasm.mjs':'glue'}))writeFileSync(path.join(p,name),bytes);
 return fn(p);
}finally{rmSync(p,{force:true,recursive:true});}}
test('finalizer precaches every runtime JS, worker, mjs, wasm with stable hash',()=>fixture(p=>{
 const stats=finalize(p),sw=readFileSync(path.join(p,'sw.js'),'utf8');
 for(const x of ['assets/index-ABCD.js','assets/worker-xyz.js','ort-wasm/ort-wasm.wasm','ort-wasm/ort-wasm.mjs','manifest.webmanifest'])assert.ok(sw.includes(x));
 assert.match(sw,/app-shell-[a-f0-9]{16}/);assert.equal(stats.precache,7);
}));
test('hash changes when JS bytes change despite unchanged filename',()=>fixture(p=>{
 let a=finalize(p).build;writeFileSync(path.join(p,'assets/index-ABCD.js'),'different');writeFileSync(path.join(p,'sw.js'),swSource);
 assert.notEqual(finalize(p).build,a);
}));
test('fails closed without runtime and without compiled app chunks',()=>fixture(p=>{
 rmSync(path.join(p,'ort-wasm/ort-wasm.wasm'));assert.throws(()=>finalize(p),/runtime/);
}));

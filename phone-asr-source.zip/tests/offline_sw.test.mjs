import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs';
const source=fs.readFileSync(new URL('../public/sw.js',import.meta.url),'utf8');
const ORIGIN='https://example.test',ROOT=ORIGIN+'/demo/';
function harness(){
 const handlers={}, stores=new Map(),requests=[], data=new Map();let online=true;
 class FakeResponse {constructor(text){this.body=text;this.ok=true;this.type='basic';}clone(){return new FakeResponse(this.body);}}
 const normalized=input=>typeof input==='string'?input:input.url;
 const caches={
  async open(name){if(!stores.has(name))stores.set(name,new Map());const map=stores.get(name);
   return {put:async(url,response)=>map.set(normalized(url),response.clone()),addAll:async urls=>{
    const received=await Promise.all(urls.map(async url=>[url,await fetcher(url)]));
    for (const [url,response] of received)map.set(normalized(url),response.clone());
   }};},
  async match(url){for (const map of stores.values()){const v=map.get(normalized(url));if(v)return v.clone();}return undefined;},
  async keys(){return [...stores.keys()];},async delete(key){return stores.delete(key);}
 };
 const fetcher=async req=>{const url=normalized(req);requests.push(url);if(!online)throw Error('NETWORK_OFF');return new FakeResponse(data.get(url)??'response:'+url);};
 const self={location:{origin:ORIGIN},registration:{scope:ROOT},clients:{claim:async()=>{}},skipWaiting:async()=>{},addEventListener:(key,callback)=>handlers[key]=callback};
 vm.runInNewContext(source,{self,URL,caches,fetch:fetcher,Response:{error:()=>new FakeResponse('no response')}});
 const dispatch=async(kind,request)=>{
   let promise;handlers[kind]({request,waitUntil:p=>promise=p,respondWith:p=>promise=p});
   return await promise;
 };
 return {dispatch,stores,requests,setOnline:v=>online=v,cache:caches,data};
}
test('shell installs while online then restarts when fully offline',async()=>{
 const h=harness();await h.dispatch('install');await h.dispatch('activate');
 h.setOnline(false);
 const result=await h.dispatch('fetch',{method:'GET',url:ROOT,mode:'navigate'});
 assert.equal(result.body,'response:'+ROOT+'index.html');
});
test('fetches unprecached same-origin file once and uses cache offline',async()=>{
 const h=harness();await h.dispatch('install');
 const req={url:ROOT+'assets/chunk-123.js',method:'GET',mode:'cors'};
 assert.equal((await h.dispatch('fetch',req)).body,'response:'+req.url);
 h.setOnline(false);assert.equal((await h.dispatch('fetch',req)).body,'response:'+req.url);
 assert.equal(h.requests.filter(x=>x===req.url).length,1);
});
test('never intercepts requests to Hugging Face, other origins or sibling repo path',async()=>{
 const h=harness();await h.dispatch('install');
 for(const url of ['https://huggingface.co/onnx-community/whisper-tiny','https://example.test/other/index.html']){
  assert.equal(await h.dispatch('fetch',{url,method:'GET',mode:'cors'}),undefined);
 }
 assert.equal(h.requests.filter(x=>x.includes('huggingface')).length,0);
});
test('deletes old shell but leaves unrelated model cache intact',async()=>{
 const h=harness();h.stores.set('huggingface-model-cache',new Map());h.stores.set('portuguese-asr-app-shell-old',new Map());await h.dispatch('install');await h.dispatch('activate');
 assert.ok(h.stores.has('huggingface-model-cache'));assert.equal(h.stores.has('portuguese-asr-app-shell-old'),false);
});

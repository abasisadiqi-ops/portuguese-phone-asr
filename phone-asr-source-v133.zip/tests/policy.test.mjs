import test from 'node:test';import assert from 'node:assert/strict';
import {MODEL_ID,localeGuard,inferenceOptions,deviceKind,receipt,validateBundlePolicy} from '../src/policy.mjs';
test('only multilingual Whisper model',()=>{assert.equal(MODEL_ID,'onnx-community/whisper-tiny');assert.ok(!MODEL_ID.endsWith('.en'));});
test('locale target validated and not inferred',()=>{for(const x of ['pt-PT','pt-BR'])assert.equal(localeGuard(x),x);assert.throws(()=>localeGuard('en-US'));});
test('transcription not translation',()=>{const x=inferenceOptions(4);assert.equal(x.language,'portuguese');assert.equal(x.task,'transcribe');assert.ok(x.max_new_tokens<=224);});
test('duration range enforced',()=>{for(const x of [-1,0,NaN,31])assert.throws(()=>inferenceOptions(x));assert.doesNotThrow(()=>inferenceOptions(30));});
test('backend selection never fabricates WebGPU',()=>{assert.equal(deviceKind('auto',false),'wasm');assert.equal(deviceKind('auto',true),'webgpu');assert.equal(deviceKind('cpu',true),'wasm');assert.throws(()=>deviceKind('gpu',false));});
test('receipt never counts a study minute or certifies offline',()=>{const v=receipt({locale:'pt-PT',backend:'wasm',ms:12000,text:'Olá',onlineHint:false,audioHash:'sha',source:'test.wav'});assert.equal(v.study_minutes,0);assert.equal(v.proof_of_airplane_mode,'NOT_ATTESTED');assert.equal(v.proof_of_physical_iphone,'NOT_ATTESTED');assert.equal(v.accent_detected,false);assert.equal(v.connection_hint_from_browser,'offline_hint_only');assert.equal(v.model_integrity_review,'NOT_ATTESTED');});
test('invalid observation rejected',()=>{assert.throws(()=>receipt({locale:'xx',backend:'wasm',ms:2,text:''}));assert.throws(()=>receipt({locale:'pt-BR',backend:'gpu',ms:2,text:''}));});
test('private state and audio cannot be deployed',()=>{assert.equal(validateBundlePolicy(['assets/app.js','manifest.webmanifest']),true);for(const p of ['LEARNING/a.json','PROGRAM_STATE_ORIGINAL.json','foo.wav','HISTORY/a','ggml-base.bin'])assert.equal(validateBundlePolicy([p]),false);});
test('model registry is constrained to two multilingual models with independent honest receipts',async()=>{
  const {MODELS,modelGuard}=await import('../src/policy.mjs');
  assert.equal(Object.keys(MODELS).length,2);
  for(const key of ['tiny','base']) assert.equal(modelGuard(MODELS[key].id),MODELS[key].id);
  for(const id of ['onnx-community/whisper-base.en','private/whisper-huge',undefined])assert.throws(()=>modelGuard(id));
  const r=receipt({locale:'pt-PT',model:MODELS.base.id,backend:'wasm',ms:3000,text:'teste',audioHash:'a'.repeat(64)});
  assert.equal(r.model,MODELS.base.id);assert.equal(r.study_minutes,0);
  assert.equal(r.proof_of_airplane_mode,'NOT_ATTESTED');
});

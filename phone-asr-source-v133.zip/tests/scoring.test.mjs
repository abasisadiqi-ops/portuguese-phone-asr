import test from 'node:test';import assert from 'node:assert/strict';
import {tokens,wordErrors,comparisonRecord} from '../src/scoring.mjs';
import {MODELS,receipt} from '../src/policy.mjs';
const reference='Hoje estou em casa e quero aprender português todos os dias.';
test('Portuguese normalization ignores case/punctuation but never erases accent contrasts',()=>{
  assert.deepEqual(tokens(' NÃO — Pôr, CAFÉ! '),['não','pôr','café']);
  assert.equal(wordErrors('Pôr café','por cafe').word_errors,2);
  assert.equal(wordErrors('Olá, mãe!','olá mãe').wer,0);
});
test('user-observed Tiny misrecognition has two word errors, matching reference has zero',()=>{
  const bad='Hoje estou em casa e quero aprender por ti todos os dias.';
  const e=wordErrors(reference,bad);assert.equal(e.reference_words,11);assert.equal(e.recognized_words,12);
  assert.equal(e.word_errors,2);assert.ok(Math.abs(e.wer-2/11)<1e-10);
  assert.equal(wordErrors(reference,reference).wer,0);
});
test('WER may exceed 100 percent for long hallucinated output and must not be hidden',()=>{
  assert.equal(wordErrors('bom','bom dia e noite').wer,3);
});
test('never scores an absent, invalid, or overlong reference',()=>{
  for(const s of ['', '   ','. !', 'a'.repeat(1201)])assert.throws(()=>wordErrors(s,'teste'));
});
test('comparison aligns transcript/model/backend with one audio hash and target; no study credit',()=>{
  const h='a'.repeat(64);
  const make=(model,text,ms)=>receipt({locale:'pt-PT',model,backend:'wasm',ms,text,onlineHint:false,audioHash:h,source:'microphone_recording'});
  const tiny=make(MODELS.tiny.id,'Hoje estou em casa e quero aprender por ti todos os dias.',1152);
  const base=make(MODELS.base.id,reference,2000);
  const res=comparisonRecord({locale:'pt-PT',reference,audioHash:h,source:'microphone_recording',observations:[tiny,base]});
  assert.equal(res.observations.length,2);
  assert.equal(res.observations[0].evaluation.word_errors,2);
  assert.equal(res.observations[1].evaluation.word_errors,0);
  assert.equal(res.study_minutes,0);assert.equal(res.learning_progress_updated,false);
  assert.equal(res.proof_of_airplane_mode,'NOT_ATTESTED');
  assert.equal(res.reference_source,'user_supplied_unverified');
  assert.equal(res.audio_sha256,h);
});
test('absent reference gives no phantom accuracy score',()=>{
  const r=receipt({locale:'pt-BR',model:MODELS.base.id,backend:'wasm',ms:33,text:'bom dia',audioHash:'d'.repeat(64),source:'local_file'});
  const c=comparisonRecord({locale:'pt-BR',audioHash:'d'.repeat(64),observations:[r]});
  assert.equal(c.reference_source,'NOT_PROVIDED');assert.ok(!('evaluation' in c.observations[0]));
});
test('different recording/locale cannot be passed off as same-audio comparison',()=>{
  const r=receipt({locale:'pt-PT',model:MODELS.tiny.id,backend:'wasm',ms:2,text:'bom dia',audioHash:'f'.repeat(64)});
  assert.throws(()=>comparisonRecord({locale:'pt-BR',audioHash:'f'.repeat(64),observations:[r]}));
  assert.throws(()=>comparisonRecord({locale:'pt-PT',audioHash:'e'.repeat(64),observations:[r]}));
});

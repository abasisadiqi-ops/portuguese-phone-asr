#!/usr/bin/env python3
"""Genuine Chromium shell, PCM decode and synthetic microphone recording checks.
Whisper is not mocked into a success claim and no real model is loaded.
"""
from pathlib import Path
import re,wave,math,struct,io,asyncio
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def main():
  async with async_playwright() as p:
   browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
   ctx=await browser.new_context(viewport={'width':390,'height':844},accept_downloads=True)
   page=await ctx.new_page()
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   # Managed Chromium disallows HTTP navigation. Inline the four small application
   # ES modules in-memory for UI testing; this is NOT a production Vite build.
   html=(ROOT/'index.html').read_text().replace('<script type="module" src="./src/app.mjs"></script>','')
   await page.set_content(html,wait_until='load')
   sources=[]
   for name in ('policy','scoring','audio','engine','app'):
    script=(ROOT/'src'/f'{name}.mjs').read_text()
    script=re.sub(r"^import (?:.*) from ['\"].*?['\"];?\s*$",'',script,flags=re.M)
    script=script.replace('export class ','class ').replace('export async function ','async function ').replace('export function ','function ').replace('export const ','const ')
    sources.append(script)
   await page.add_script_tag(type='module',content='\n'.join(sources)+'\nwindow.__audioTest={decodeBlobTo16k,digestSha256};')
   await page.wait_for_function("document.querySelector('#capability').textContent.includes('Secure origin')")
   assert await page.locator('h1').inner_text()=='Portuguese Local ASR Lab'
   assert await page.locator('#run').is_disabled()
   # Actual browser-generated 1 second 16 kHz mono sine PCM WAV file.
   frame_rate=16000; frames=b''.join(struct.pack('<h',int(0.2*32767*math.sin(2*math.pi*440*i/frame_rate))) for i in range(frame_rate))
   filebytes=io.BytesIO()
   with wave.open(filebytes,'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(frame_rate);wav.writeframes(frames)
   await page.locator('#file').set_input_files({'name':'reference.wav','mimeType':'audio/wav','buffer':filebytes.getvalue()})
   assert 'reference.wav' in await page.locator('#selection').inner_text()
   assert await page.locator('#run').is_disabled() # model not loaded
   metrics=await page.evaluate("""async()=>{
    const raw=document.querySelector('#file').files[0];const pcm=await window.__audioTest.decodeBlobTo16k(raw);
    let power=0;for(const v of pcm)power+=v*v;return {len:pcm.length,rms:Math.sqrt(power/pcm.length),sha:await window.__audioTest.digestSha256(raw)};
   }""")
   # set_content uses opaque origin: crypto.subtle may be unavailable. Real HTTPS is required for SHA.
   assert metrics['len']==16000 and 0.12<metrics['rms']<0.17,metrics
   assert metrics['sha'] is None or len(metrics['sha'])==64,metrics
   # Real MediaRecorder creates an encoded blob from an oscillator, Chromium decodes it.
   encoded=await page.evaluate("""async()=>{
     const context=new AudioContext();const o=context.createOscillator();o.frequency.value=330;
     const dest=context.createMediaStreamDestination();o.connect(dest);o.start();
     const recorder=new MediaRecorder(dest.stream);const chunks=[];recorder.ondataavailable=e=>chunks.push(e.data);
     const done=new Promise(resolve=>recorder.onstop=resolve);recorder.start();
     await new Promise(resolve=>setTimeout(resolve,600));recorder.stop();await done;
     o.stop();await context.close();const blob=new Blob(chunks,{type:recorder.mimeType});
     const pcm=await window.__audioTest.decodeBlobTo16k(blob);return {mime:blob.type,bytes:blob.size,samples:pcm.length};
   }""")
   assert encoded['bytes']>100 and encoded['samples']>2400,encoded
   assert not errors,errors
   await page.screenshot(path=str(ROOT/'tests'/'phone_390_preview.png'),full_page=True)
   print('Chromium 390px UI + real WAV decode + real encoded microphone stream passed (offline shell NOT browser-tested):',metrics,encoded)
   await browser.close()

if __name__=='__main__':asyncio.run(main())

#!/usr/bin/env python3
"""Chromium UI integration with a FAKE model, but real WAV decoding, injected fixture hash, actual UI handlers.
No neural model loaded. This tests no data loss on model swaps and avoids fake ASR claims.
"""
from pathlib import Path
from playwright.async_api import async_playwright
import asyncio,io,math,struct,wave,re,json
ROOT=Path(__file__).resolve().parents[1]
REFERENCE='Hoje estou em casa e quero aprender português todos os dias.'
TINY='Hoje estou em casa e quero aprender por ti todos os dias.'

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':390,'height':844},accept_downloads=True)
  page=await context.new_page()
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  html=(ROOT/'index.html').read_text().replace('<script type="module" src="./src/app.mjs"></script>','')
  await page.set_content(html,wait_until='load')
  await page.evaluate("""()=>{window.__testML={
    env:{backends:{onnx:{wasm:{}}}},
    pipeline:async(task,model,opts)=>{
      if(task!=='automatic-speech-recognition'||opts.device!=='wasm')throw Error('Invalid mock setup');
      return Object.assign(async(samples,decode)=>({text:model.endsWith('whisper-base')?
       'Hoje estou em casa e quero aprender português todos os dias.':
       'Hoje estou em casa e quero aprender por ti todos os dias.'}),
      {dispose:async()=>{}});
    }
  };}""")
  source=[]
  for name in ('policy','scoring','audio','engine','app'):
   text=(ROOT/'src'/f'{name}.mjs').read_text()
   text=re.sub(r"^import (?:.*) from ['\"].*?['\"];?\s*$",'',text,flags=re.M)
   text=text.replace('export class ','class ').replace('export async function ','async function ').replace('export function ','function ').replace('export const ','const ')
   text=text.replace("await import('@huggingface/transformers')",'window.__testML')
   if name=='app':
    text=text.replace('digestSha256(blob)',"Promise.resolve('a'.repeat(64))")
    text=text.replace("new URL('./ort-wasm/',document.baseURI).href","'https://fixture.invalid/ort-wasm/'")
   source.append(text)
  await page.add_script_tag(type='module',content='\n'.join(source))
  await page.wait_for_function("document.querySelector('#capability').textContent.includes('Secure origin')")
  assert not await page.evaluate('window.isSecureContext')  # opaque test origin, so injected fixture hash is used
  # Real WAV (one second / 16 kHz / PCM16) travels through actual browser file-input and Web Audio decoding.
  frames=b''.join(struct.pack('<h',int(.25*32767*math.sin(2*math.pi*300*i/16000))) for i in range(16000))
  bio=io.BytesIO()
  with wave.open(bio,'wb') as f:
   f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000);f.writeframes(frames)
  await page.locator('#file').set_input_files({'name':'same.wav','mimeType':'audio/wav','buffer':bio.getvalue()})
  await page.locator('#reference').fill(REFERENCE)
  await page.locator('#model').select_option('tiny')
  await page.locator('#backend').select_option('cpu')
  await page.locator('#load').click()
  await page.wait_for_function("document.querySelector('#status').textContent.includes('Tiny loaded')")
  await page.locator('#run').click()
  await page.wait_for_function("document.querySelector('#compareRows').textContent.includes('18.2%')")
  assert TINY in await page.locator('#transcript').input_value()
  assert await page.locator('#model').is_disabled()
  await page.locator('#unload').click()
  await page.wait_for_function("!document.querySelector('#model').disabled")
  assert '18.2%' in await page.locator('#compareRows').inner_text()
  assert 'same.wav' in await page.locator('#selection').inner_text()
  await page.locator('#model').select_option('base')
  await page.locator('#load').click()
  await page.wait_for_function("document.querySelector('#status').textContent.includes('Base loaded')")
  await page.locator('#run').click()
  await page.wait_for_function("document.querySelector('#compareRows').children.length===2")
  assert REFERENCE in await page.locator('#transcript').input_value()
  assert '0.0%' in await page.locator('#compareRows').inner_text()
  async with page.expect_download() as event:
   await page.locator('#compareExport').click()
  d=await event.value
  assert d.suggested_filename=='portuguese-tiny-base-comparison.json'
  temp=ROOT/'tests'/'comparison_browser_preview.json'
  await d.save_as(str(temp))
  receipt=json.loads(temp.read_text());temp.unlink()
  assert receipt['study_minutes']==0 and len(receipt['observations'])==2
  assert receipt['observations'][0]['evaluation']['word_errors']==2
  assert receipt['observations'][1]['evaluation']['word_errors']==0
  assert receipt['observations'][0]['model']=='onnx-community/whisper-tiny'
  assert receipt['observations'][1]['model']=='onnx-community/whisper-base'
  assert receipt['audio_sha256']!='not-available' and len(receipt['audio_sha256'])==64
  await page.locator('#discard').click()
  assert 'No results' in await page.locator('#compareRows').inner_text()
  assert not errors,errors
  print('390px Chromium: same-WAV real decode / injected hash + MOCK Tiny/Base pipeline swap + WER + JSON export + discard passed')
  await browser.close()

if __name__=='__main__':asyncio.run(main())

import test from 'node:test';import assert from 'node:assert/strict';
import {LocalWhisperEngine,findUsableGPU} from '../src/engine.mjs';
test('truly executes provided model inference, no translation',async()=>{let got;const engine=new LocalWhisperEngine({pipelineFactory:async(task,model,opts)=>{got={task,model,opts};return async(samples,settings)=>({text:' Olá, tudo bem? ',settings});}});assert.equal(await engine.prepare({preference:'cpu'}),'wasm');const ans=await engine.transcribe(new Float32Array(16000));assert.equal(ans.text,'Olá, tudo bem?');assert.equal(got.task,'automatic-speech-recognition');assert.equal(got.opts.dtype,'q8');});
test('falls back from failed WebGPU to CPU in auto mode',async()=>{const requests=[];const engine=new LocalWhisperEngine({pipelineFactory:async(_,__,opts)=>{requests.push(opts.device);if(opts.device==='webgpu')throw Error('unavailable');return async()=>({text:'fallback'});}});assert.equal(await engine.prepare({preference:'auto',hasGPU:true}),'wasm');assert.deepEqual(requests,['webgpu','wasm']);});
test('forced GPU rejects failure instead of obscuring it',async()=>{const engine=new LocalWhisperEngine({pipelineFactory:async()=>{throw Error('GPU');}});await assert.rejects(engine.prepare({preference:'gpu',hasGPU:true}));});
test('never credits unsupported audio',async()=>{const engine=new LocalWhisperEngine({pipelineFactory:async()=>async()=>({text:'yes'})});await engine.prepare();await assert.rejects(engine.transcribe(new Float32Array(16000*31)));});
test('only reports available adapter and handles errors',async()=>{assert.equal(await findUsableGPU({}),false);assert.equal(await findUsableGPU({gpu:{requestAdapter:async()=>({})}}),true);assert.equal(await findUsableGPU({gpu:{requestAdapter:async()=>{throw Error('failed')}}}),false);});
test('unload discards model in memory',async()=>{let disposed=false;const engine=new LocalWhisperEngine({pipelineFactory:async()=>Object.assign(async()=>({text:''}),{dispose:async()=>{disposed=true;}})});await engine.prepare();await engine.unload();assert.equal(disposed,true);assert.equal(engine.backend,null);});
test('allows multilingual Whisper Base without altering legacy Tiny default',async()=>{
  const req=[];
  const engine=new LocalWhisperEngine({pipelineFactory:async(task,model,opts)=>{
    req.push({task,model,device:opts.device});return Object.assign(async()=>({text:' Olá do Base. '}),{dispose:async()=>{}});
  }});
  assert.equal(await engine.prepare({model:'onnx-community/whisper-base',preference:'cpu'}),'wasm');
  const out=await engine.transcribe(new Float32Array(16000));
  assert.equal(out.model,'onnx-community/whisper-base');assert.equal(out.backend,'wasm');
  assert.deepEqual(req.map(x=>x.model),['onnx-community/whisper-base']);
  await engine.unload();assert.equal(engine.model,null);
});
test('switching without unloading rejects; a failed Base load does not forge success',async()=>{
  const e=new LocalWhisperEngine({pipelineFactory:async(_t,model)=>{
    if(model.endsWith('-base'))throw Error('model missing / out of RAM');
    return async()=>({text:'tiny works'});
  }});
  await e.prepare({model:'onnx-community/whisper-tiny'});
  await assert.rejects(e.prepare({model:'onnx-community/whisper-base'}),/Unload/);
  await e.unload();await assert.rejects(e.prepare({model:'onnx-community/whisper-base'}),/RAM/);
  assert.equal(e.pipe,null);assert.equal(e.model,null);
  await e.prepare({model:'onnx-community/whisper-tiny'});
  assert.equal((await e.transcribe(new Float32Array(16000))).text,'tiny works');
});

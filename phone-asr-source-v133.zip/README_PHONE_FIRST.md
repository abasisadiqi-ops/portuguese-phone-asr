# Portuguese phone-only local ASR lab — v0.2 source candidate (10 October 2026)

This *isolated* public-deployable web app is NOT the private multilingual master and cannot award study credit. It is an experiment for **on-device inference in iPhone Safari**. Offline success on an actual iPhone remains NOT TESTED. The v1.0.31 native Xcode project is an optional fallback, not a required step.

## What is actually implemented

- No account, proxy, server audio upload, paid API, voice cloning, user speech training, or login. Audio is decoded locally with Web Audio. Recording comes from browser microphone permission. Model files download from Hugging Face on first load. The app uses `@huggingface/transformers@4.3.0`, a multilingual `onnx-community/whisper-tiny` model (not English-only), Portuguese transcribe mode, WebGPU where available and CPU/WASM fallback.
- App source (JS, CSS, HTML, manifest, icons) and ONNX WASM runtime are bundled on the static origin. Service worker precaches *every* built asset, including dynamic JS chunks and WASM, and only caches site-local GETs within scope; model data uses Transformers.js CacheStorage instead.
- iOS may evict cached data without notice. Never claim offline readiness without an actual airplane-mode restart test. WebGPU and CPU use **different** model files: cache the backend you intend to use offline. The iPhone can run out of RAM, especially with GPU weights. Start with CPU if GPU fails.
- European and Brazilian Portuguese are **test targets only**. A multilingual Whisper model cannot infer native accent from this selector. Recognition transcripts and source rights need separate human validation.

## Deployment from an iPhone using GitHub (no Mac or Xcode)

1. On the iPhone, upload the **single supplied** `phone-asr-source.zip` to the private GitHub repository as `phone-asr-source.zip` at the repository root. Place the workflow supplied as `tools/phone_asr_workflow.yml` in `.github/workflows/phone-portuguese-asr.yml` at the repository root (or merge the prepared GitHub branch containing it). Only the isolated 30 KB PWA source archive is uploaded, **not** the 200 KB multilingual master or any learning-state files. Alternatively, stage the PWA source folder at `EXPERIMENTS/Phone_Only_Portuguese_ASR_PWA_v0.1/` and skip the deployment ZIP. GitHub's mobile website can upload a ZIP directly; it does not need to extract the archive.
2. On GitHub's website in Safari, open **Actions** → **Phone Portuguese ASR (manual build / optional Pages)** → **Run workflow** on a branch containing this workflow (typically `main`). Leave `deploy_pages` **false** initially. A GitHub Linux runner installs dependencies, tests, builds and privately uploads `phone-portuguese-asr-static-site`. Nothing is published. CI usage is subject to the repository's GitHub Actions quotas.
3. After reviewing the Pages privacy implications and GitHub plan: Repository **Settings → Pages → Source: GitHub Actions**, then manually run the workflow with `deploy_pages` **true**. The deployment is strictly `dist/`, not the master archive. GitHub Pages URLs can be publicly accessible even when repository source is private. GitHub Free generally requires a public repository to host Pages.
4. Open the actual **HTTPS Pages URL** in iPhone Safari. Share → Add to Home Screen → Open as Web App. Choose **CPU/WASM** first to avoid extra GPU memory pressure; optionally later test WebGPU separately. Allow model download, import a short clip and transcribe online once.
5. Enable **Airplane Mode**, explicitly switch **Wi-Fi off**, fully close and reopen the Home Screen app. Without reconnecting, re-load the same backend and transcribe a **different** short clip. If the app starts but model download fails, offline ASR has **not** passed. Browser `navigator.onLine` is only a hint.
6. Export the JSON receipt, with reference transcript and consent/rights evidence recorded separately. Do not conclude that the accent is native or update study progress. Submit the receipt and your actual offline observations for independent scoring with the existing ASR tools.

## Local developer verification

```sh
npm install --no-audit --no-fund
npm test
npm run build
node tools/check_dist.mjs
python tests/test_phone_browser.py  # Chromium, synthetic audio; no real ASR weights
```

Network-accessible npm and a real HTTPS origin are necessary for the production build/test. The present conversation container cannot reach npm; **we have not executed npm install or a true production Vite build here**. The Node policy suite and an in-memory Chromium audio/UI test are real, but not proof of bundled neural inference.

## Known limits and privacy

- Loading model weights from a third-party repository creates normal network requests for public model files; the imported **audio itself is not deliberately uploaded by app code**. This is source-level privacy, not a packet-capture audit. Review browser/OS network requests before asserting stronger guarantees.
- CacheStorage limits vary by browser, disk pressure and browsing mode. Do not use private browsing for this pilot. On iPhone, add to Home Screen before final offline tests.
- The audio is kept in page memory only until discard or page closure; exported transcript JSON is an explicit file written to your phone and may be backed up by iCloud depending on where you save it.
- GitHub Pages cannot set arbitrary COOP/COEP response headers; this implementation requests single-thread CPU WASM and uses WebGPU opportunistically. It does **not** enable SharedArrayBuffer-based multithreaded inference.
- No language model, native-quality synthetic teacher, autonomous Socratic loop or real 66-hour scheduler integration is present. This PWA is an intentionally **isolated** ASR pilot.

## October 10 update — Tiny/Base same-clip comparison candidate

**User-observed milestone (not mechanically attested):** On an actual iPhone, after the user reports enabling Airplane Mode, turning Wi-Fi off, closing the Home Screen app and reopening it, Whisper Tiny multilingual on CPU/WASM generated a complete Portuguese sentence in 1.469 seconds. The app receipt did not attest airplane mode or physical hardware, and the browser's `online` flag remained `online`; this cannot be interpreted as a live network call. Earlier Tiny recordings included an incorrect `português` → `por ti` transcription. These reports apply ONLY to the earlier **Tiny CPU/WASM** build. The Base model and this updated comparison UI are not yet on-device tested.

This upgrade adds a model chooser constrained to **multilingual Tiny/Base**, retains the exact selected audio in volatile page memory while switching models, explicitly unloads model A before loading model B, retains earlier results if Base loading fails, and displays per-model transcript, actual backend and measured inference time. Base is larger (~77 MB q8 CPU / ~291 MB fp32 WebGPU); caching and memory behavior MUST be checked on the actual phone. Backend and model are separate choices; selecting European/Brazilian Portuguese is an evaluation label, not an accent detector.

**Comparison procedure on iPhone (no second recording):**

1. Choose Tiny / CPU, prepare the model (cached if previously installed), import or record one short phrase. The recording stays selected until replaced or discarded.
2. In the new comparison section, optionally type the EXACT words you said as a human-reviewed reference. No reference is supplied or inferred by the app.
3. Transcribe the selected recording. Note Tiny's transcript and time. Tap **Unload model / change backend** — this releases model memory but deliberately retains the recording and Tiny result.
4. Switch the model selector to **Base**, keep CPU backend, and prepare. First-time Base weights require Wi-Fi. If Base fails, unload/restart and go back to Tiny; comparison results should still be present during the same page session. Do **not** clear site data or use iOS low-storage mode as a workaround.
5. Transcribe the **same selected recording**, compare the two transcript rows and timings, and optionally export JSON. WER scores use word-level edit distance, NFC + lowercase + punctuation splitting; Portuguese diacritic contrasts are **not** discarded. The number is recognition accuracy against your supplied reference, NOT pronunciation quality or speaker accent certainty.
6. To attempt Base fully offline later, load and transcribe Base online once, then turn on Airplane Mode, explicitly disable Wi-Fi, completely close and reopen the Home Screen app and load/transcribe a *new* recording without internet. Report exact success/failure and timestamps. An online Base test alone does not certify Base's offline cache.

No recordings, raw audio, learning-state data or model weights ship in the isolated source ZIP or compiled website. Export is manual. No study minutes are credited, and neither a user reference nor a selected locale certifies native accent or linguistic proficiency. The previously verified Tiny experience must remain available while reviewing this upgrade in a non-deploying GitHub branch.

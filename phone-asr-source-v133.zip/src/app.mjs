import {LocalWhisperEngine,findUsableGPU} from './engine.mjs';
import {decodeBlobTo16k,digestSha256} from './audio.mjs';
import {MODELS,localeGuard,MAX_SOURCE_BYTES,receipt} from './policy.mjs';
import {wordErrors,comparisonRecord} from './scoring.mjs';

const el=id=>document.getElementById(id);
let engine=null,backend=null,selectedBlob=null,selectedSource='',resultReceipt=null;
let mediaRecorder=null,mediaStream=null,recordingTimer=null;
let observations=[],currentHash=null;
const status=message=>el('status').textContent=message;
let busy=false;
function refresh(){
  el('load').disabled=busy||!!backend;
  el('unload').disabled=busy||!backend;
  el('run').disabled=busy||!backend||!selectedBlob;
  el('export').disabled=busy||!resultReceipt;
  el('compareExport').disabled=busy||!currentHash||observations.length===0;
  el('record').disabled=busy||!!mediaRecorder;
  el('stop').disabled=!mediaRecorder;
  el('file').disabled=busy||!!mediaRecorder;
  el('backend').disabled=busy||!!backend;
  el('model').disabled=busy||!!backend;
  el('locale').disabled=busy;
  el('reference').disabled=busy;
  el('discard').disabled=busy;
}
async function work(fn){
  if(busy)return;
  busy=true;refresh();
  try{await fn();}catch(e){status(`Error: ${e?.message||String(e)}. Prior same-audio observations were preserved. No study progress credited.`);}
  finally{busy=false;refresh();}
}
function downloadJSON(data,filename){
  const blob=new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function renderComparison(){
  const tbody=el('compareRows');tbody.replaceChildren();
  const reference=el('reference').value.trim();
  const info=el('compareInfo');
  if(!observations.length){
    const row=tbody.insertRow(),cell=row.insertCell();cell.colSpan=4;cell.textContent='No results for the selected recording yet.';
    info.textContent='Compare with one audio recording, same evaluation target. Add an optional manually verified reference.';
    refresh();return;
  }
  for(const obs of observations){
    const row=tbody.insertRow();
    row.insertCell().textContent=`${obs.model.endsWith('whisper-base')?'Base':'Tiny'} / ${obs.effective_device}`;
    row.insertCell().textContent=obs.transcript;
    let wer='—';
    if(reference){try{wer=`${(100*wordErrors(reference,obs.transcript).wer).toFixed(1)}%`;}catch{wer='Invalid reference';}}
    row.insertCell().textContent=wer;
    row.insertCell().textContent=`${(obs.elapsed_inference_ms/1000).toFixed(2)} s`;
  }
  info.textContent=`${observations.length} result(s) for exactly one audio SHA-256 (${currentHash?.slice(0,12)||'not available'}…). ${reference?'Reference entered by user; no independent verification.':'Enter reference to calculate WER.'}`;
  refresh();
}
function clearResults(){resultReceipt=null;currentHash=null;observations=[];el('transcript').value='';renderComparison();}
function choose(blob,source,label=source){
  if(blob.size<=0||blob.size>MAX_SOURCE_BYTES)throw new Error('Recording is empty or over 16 MiB');
  selectedBlob=blob;selectedSource=source;el('reference').value='';clearResults();
  el('selection').textContent=`Selected ${label} (${(blob.size/1024).toFixed(1)} KiB). Keep this exact recording selected when switching models.`;
  refresh();
}
async function detect(){
  const gpu=await findUsableGPU();
  el('capability').textContent=`Secure origin: ${isSecureContext?'yes':'NO'} | WebGPU adapter: ${gpu?'available':'not available'} | App shell service worker: ${'serviceWorker' in navigator?'supported':'unsupported'} | Online hint: ${navigator.onLine?'online':'offline'} (not attestation)`;
  return gpu;
}
async function storageStatus(){
  try{
    const estimate=await navigator.storage?.estimate?.();
    const persisted=await navigator.storage?.persisted?.();
    if(!estimate){el('storage').textContent='Browser storage estimate unavailable; model caching must be tested manually.';return;}
    const m=x=>Math.round(x/1024/1024);
    el('storage').textContent=`Approx. site storage: ${m(estimate.usage||0)} MiB used / ${m(estimate.quota||0)} MiB quota. Persistence: ${persisted?'granted':'not established'}. Cache can still be evicted; airplane-mode verification is essential.`;
  }catch{el('storage').textContent='Browser storage status unavailable; online testing can continue.';}
}
storageStatus();
const gpuPromise=detect();
if('serviceWorker' in navigator && isSecureContext){
  navigator.serviceWorker.register('./sw.js').catch(e=>status(`Service worker unavailable: ${e.message}. Online use may still work.`));
}
el('load').addEventListener('click',()=>work(async()=>{
  const model=MODELS[el('model').value];
  if(!model)throw new Error('Invalid model');
  status(`Preparing ${model.label}. Initial download requires internet; CPU and GPU weights are separate.`);
  const gpu=await gpuPromise;
  const {pipeline,env}=await import('@huggingface/transformers');
  env.backends.onnx.wasm.wasmPaths=new URL('./ort-wasm/',document.baseURI).href;
  engine=new LocalWhisperEngine({pipelineFactory:pipeline,envObject:env});
  backend=await engine.prepare({model:model.id,preference:el('backend').value,hasGPU:gpu,onProgress:p=>{
    if(p?.status==='fallback')status('WebGPU failed; falling back to CPU/WASM. Additional model files may download.');
    else if(p?.status)status(`${model.label}: ${p.status}${typeof p.progress==='number'?' '+Math.round(p.progress)+'%':''}`);
  }});
  await storageStatus();
  status(`${model.label} loaded using ${backend}. Existing same-audio results remain; actual transcription and offline availability require testing.`);
}));
el('unload').addEventListener('click',()=>work(async()=>{
  if(engine)await engine.unload();engine=null;backend=null;
  status('Model unloaded from memory. The recording and prior comparison results remain. Choose the other model, then load and transcribe the SAME recording. Cached weights are not deleted.');
}));
el('file').addEventListener('change',event=>{
  try{const file=event.target.files?.[0];if(file)choose(file,'local_file',file.name);}
  catch(e){selectedBlob=null;selectedSource='';clearResults();el('selection').textContent='No valid audio selected';status(e.message);refresh();}
});
el('locale').addEventListener('change',()=>{
  el('reference').value='';clearResults();status('Evaluation target changed. Comparison cleared; retranscribe the same recording for this target. No accent was detected.');
});
el('reference').addEventListener('input',renderComparison);
el('run').addEventListener('click',()=>work(async()=>{
  const blob=selectedBlob,source=selectedSource;
  if(!blob||!engine||!backend)throw new Error('Select a clip and prepare a model first');
  const model=engine.model;
  status('Decoding the selected recording entirely in your browser...');
  const [pcm,sha]=await Promise.all([decodeBlobTo16k(blob),digestSha256(blob)]);
  if(!sha)throw new Error('Audio SHA-256 unavailable: cannot guarantee same-audio comparison');
  if(currentHash&&currentHash!==sha)throw new Error('Audio changed without a new selection');
  status(`Running ${model.endsWith('whisper-base')?'Base':'Tiny'} on ${backend} (${(pcm.length/16000).toFixed(1)}s audio)...`);
  const output=await engine.transcribe(pcm);
  resultReceipt=receipt({locale:localeGuard(el('locale').value),model:output.model,backend:output.backend,
    ms:output.ms,text:output.text,onlineHint:navigator.onLine,audioHash:sha,source});
  currentHash=sha;
  observations=observations.filter(o=>!(o.model===output.model&&o.effective_device===output.backend));
  observations.push(resultReceipt);
  el('transcript').value=output.text;
  renderComparison();
  status(`${output.model.endsWith('whisper-base')?'Base':'Tiny'} transcription in ${(output.ms/1000).toFixed(2)}s. Same recorded audio can be compared after unloading. Online hint and airplane-mode status are NOT attested. Study minutes: 0.`);
}));
el('export').addEventListener('click',()=>{if(resultReceipt)downloadJSON(resultReceipt,'portuguese-local-asr-observation.json');});
el('compareExport').addEventListener('click',()=>{
  if(!currentHash||!observations.length)return;
  try{const evidence=comparisonRecord({locale:el('locale').value,reference:el('reference').value,
    audioHash:currentHash,source:selectedSource,observations});
    downloadJSON(evidence,'portuguese-tiny-base-comparison.json');
  }catch(e){status(`Cannot export comparison: ${e.message}`);}
});
el('discard').addEventListener('click',()=>{
  if(busy)return;
  selectedBlob=null;selectedSource='';clearResults();el('file').value='';el('reference').value='';
  el('selection').textContent='No audio selected';status('Recording, transcript and comparison results discarded from page memory. Model cache is unchanged.');refresh();
});
el('record').addEventListener('click',async()=>{
  if(mediaRecorder||busy)return;
  try{
    if(!isSecureContext||!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined')throw new Error('Microphone capture requires Safari HTTPS plus permission');
    mediaStream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:false},video:false});
    const options=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));
    mediaRecorder=new MediaRecorder(mediaStream,options?{mimeType:options}:undefined);
    const parts=[],recorder=mediaRecorder;
    recorder.ondataavailable=e=>{if(e.data.size>0)parts.push(e.data);};
    recorder.onerror=e=>status(`Recorder error: ${e.error?.message||'unknown'}`);
    recorder.onstop=()=>{
      clearTimeout(recordingTimer);
      mediaStream?.getTracks().forEach(t=>t.stop());mediaStream=null;mediaRecorder=null;
      try{choose(new Blob(parts,{type:recorder.mimeType||'audio/mp4'}),'microphone_recording');status('Local microphone clip ready. Transcribe with Tiny and Base in sequence.');}
      catch(e){status(`Recorder error: ${e.message}`);}refresh();
    };
    recorder.start(250);
    recordingTimer=setTimeout(()=>{if(recorder.state==='recording')recorder.stop();},20000);
    status('Recording locally for up to 20 seconds. Tap Stop when ready.');refresh();
  }catch(e){mediaStream?.getTracks().forEach(t=>t.stop());mediaStream=null;mediaRecorder=null;
    status(`Cannot record: ${e.message}`);refresh();}
});
el('stop').addEventListener('click',()=>{if(mediaRecorder?.state==='recording')mediaRecorder.stop();});
window.addEventListener('beforeunload',()=>{
  if(mediaRecorder?.state==='recording')mediaRecorder.stop();
  mediaStream?.getTracks().forEach(t=>t.stop());
});
refresh();renderComparison();

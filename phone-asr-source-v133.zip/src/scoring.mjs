// Optional human-supplied reference scoring. No pronunciation quality inference.
// Portuguese diacritics are preserved intentionally: 'pôr' and 'por' are distinct.
export const MAX_REFERENCE_CHARS=1200;
export function tokens(text){
  if(typeof text!=='string' || text.length>MAX_REFERENCE_CHARS)throw new Error('Reference/transcript exceeds 1200 characters');
  // NFC and lowercasing; punctuation splits tokens; apostrophes and dashes split words.
  const textNorm=text.normalize('NFC').toLocaleLowerCase('pt');
  return textNorm.match(/[\p{L}\p{N}]+(?:[\p{M}]+[\p{L}\p{N}]*)*/gu)||[];
}
export function wordErrors(reference,hypothesis){
  const ref=tokens(reference),hyp=tokens(hypothesis);
  if(!ref.length)throw new Error('Enter a nonempty human-reviewed reference before scoring');
  if(ref.length>150||hyp.length>150)throw new Error('Too many words to score');
  // Levenshtein on normalized word tokens; insertions/deletions/substitutions.
  let previous=Array.from({length:hyp.length+1},(_,i)=>i);
  for(let i=1;i<=ref.length;i++){
    const next=[i];
    for(let j=1;j<=hyp.length;j++)next.push(Math.min(
      previous[j]+1, next[j-1]+1, previous[j-1]+(ref[i-1]===hyp[j-1]?0:1)));
    previous=next;
  }
  const editDistance=previous[hyp.length];
  return {reference_words:ref.length,recognized_words:hyp.length,word_errors:editDistance,
    wer:editDistance/ref.length,normalization:'NFC, lowercase pt, punctuation as boundaries, accents preserved'};
}
export function comparisonRecord({locale,reference='',audioHash,source,observations=[]}){
  if(!['pt-PT','pt-BR'].includes(locale))throw new Error('Invalid locale');
  if(!audioHash||typeof audioHash!=='string')throw new Error('An audio SHA-256 is required to compare');
  const matching=observations.filter(o=>o?.audio_sha256===audioHash&&o?.target_locale===locale);
  if(!matching.length)throw new Error('No matching observations for this audio/locale');
  const filtered=matching.map(o=>({model:o.model,backend:o.effective_device,inference_ms:o.elapsed_inference_ms,
    transcript:o.transcript,...(reference.trim()?{evaluation:wordErrors(reference,o.transcript)}:{})}));
  return {schema:'phone-only-asr-comparison-v1',created_utc:new Date().toISOString(),target_locale:locale,
    source,audio_sha256:audioHash,reference_source:reference.trim()?'user_supplied_unverified':'NOT_PROVIDED',
    ...(reference.trim()?{reference_transcript:reference.trim()}:{}),
    observations:filtered,proof_of_airplane_mode:'NOT_ATTESTED',proof_of_physical_iphone:'NOT_ATTESTED',
    study_minutes:0,learning_progress_updated:false,
    warning:'Same recorded audio; human reference not independently verified; WER is transcription accuracy only.'};
}

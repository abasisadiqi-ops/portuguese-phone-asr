import {MODEL_ID,modelGuard, SAMPLE_RATE, inferenceOptions, deviceKind} from './policy.mjs';
export class LocalWhisperEngine {
  constructor({pipelineFactory, envObject}) {
    if(typeof pipelineFactory !== 'function') throw new Error('Missing pipeline implementation');
    this.pipelineFactory=pipelineFactory; this.envObject=envObject; this.pipe=null;this.backend=null;this.model=null;
  }
  async prepare({preference='auto',hasGPU=false,model=MODEL_ID,onProgress=()=>{}}={}) {
    modelGuard(model);
    if(this.pipe) {
      if(this.model!==model)throw new Error('Unload the current model before selecting another');
      return this.backend;
    }
    const requested=deviceKind(preference,hasGPU);
    if(this.envObject) {
      this.envObject.allowLocalModels=false;
      this.envObject.useBrowserCache=true;
      if(this.envObject.backends?.onnx?.wasm) this.envObject.backends.onnx.wasm.numThreads=1;
    }
    let chosen=requested;
    const load=async backend => this.pipelineFactory('automatic-speech-recognition', model, {
      device:backend, dtype:backend==='webgpu'?'fp32':'q8', progress_callback:onProgress
    });
    let pipe;
    try{pipe=await load(chosen);}catch(e){
      if(chosen!=='webgpu'||preference==='gpu')throw e;
      chosen='wasm';onProgress({status:'fallback',detail:String(e)});
      pipe=await load(chosen);
    }
    this.pipe=pipe;this.backend=chosen;this.model=model;
    return chosen;
  }
  async transcribe(pcm) {
    if(!this.pipe||!this.backend)throw new Error('Model has not been prepared');
    if(!(pcm instanceof Float32Array)||pcm.length<2400||pcm.length>30*SAMPLE_RATE) throw new Error('Unsupported 16 kHz audio');
    const seconds=pcm.length/SAMPLE_RATE;
    const start=performance.now();
    const result=await this.pipe(pcm,inferenceOptions(seconds));
    if(typeof result?.text !== 'string')throw new Error('Missing transcription text');
    return {text:result.text.trim(),ms:performance.now()-start,backend:this.backend,model:this.model};
  }
  async unload() {
    try {await this.pipe?.dispose?.();}finally{this.pipe=null;this.backend=null;this.model=null;}
  }
}
export async function findUsableGPU(navigatorLike=typeof navigator!=='undefined'?navigator:undefined) {
  try {if(!navigatorLike?.gpu) return false;
    const adapter=await Promise.race([navigatorLike.gpu.requestAdapter(),new Promise(resolve=>setTimeout(()=>resolve(null),3000))]);
    return !!adapter;
  }catch{return false;}
}
